from flask import Flask, render_template
from db import query

app = Flask(__name__)

@app.route("/")
def index():
    sql = """
        SELECT category, total_sales
        FROM sales_by_category
        ORDER BY total_sales DESC;
    """
    data = query(sql)
    return render_template("dashboard.html", data=data)

if __name__ == "__main__":
    app.run(debug=True)
